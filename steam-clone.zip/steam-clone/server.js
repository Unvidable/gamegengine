const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.use(express.json());

const users = require('./users.json');
const games = require('./games.json');

// Simple login
app.post('/login', (req, res) => {
  const { username } = req.body;
  if (!users[username]) {
    users[username] = { library: [] };
    fs.writeFileSync('./users.json', JSON.stringify(users, null, 2));
  }
  res.json({ success: true, library: users[username].library });
});

// Get game list
app.get('/games', (req, res) => {
  res.json(games);
});

// Add game to user library
app.post('/add-game', (req, res) => {
  const { username, gameId } = req.body;
  if (!users[username]) return res.status(404).send('User not found');

  if (!users[username].library.includes(gameId)) {
    users[username].library.push(gameId);
    fs.writeFileSync('./users.json', JSON.stringify(users, null, 2));
  }

  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
